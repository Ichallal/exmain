import tkinter as tk


class Marchandises:
    def __init__(self, master):
        self.master = master
        self.master.title("Marchandises")
        self.label = tk.Label(self.master, text="Marchandises")
        self.label.pack()
        self.merchandise_list = []

        # Créer une zone de texte pour afficher les marchandises
        self.merchandise_textbox = tk.Text(self.master, height=10, width=50)
        self.merchandise_textbox.pack()

        # Créer les champs pour les données des marchandises
        fields = [("Nom du produit :", "nom_produit"), ("Prix :", "prix"), ("Quantité en stock :", "quantite_stock"), ("Poids :", "poids"), ("Pays d'origine :", "pays_origine")]
        self.entries = {}
        for label_text, attr_name in fields:
            label = tk.Label(self.master, text=label_text)
            label.pack()
            entry = tk.Entry(self.master)
            self.entries[attr_name] = entry
            entry.pack()

        # Bouton pour ajouter une marchandise
        self.add_merchandise_button = tk.Button(self.master, text="Ajouter une marchandise", command=self.add_merchandise)
        self.add_merchandise_button.pack()

        # Bouton pour afficher les marchandises
        self.show_merchandise_button = tk.Button(self.master, text="Afficher les marchandises", command=self.show_merchandise)
        self.show_merchandise_button.pack()

    def add_merchandise(self):
        # Récupérer les données de la marchandise à ajouter
        nom_produit = self.entries["nom_produit"].get()
        prix = float(self.entries["prix"].get())
        quantite_stock = int(self.entries["quantite_stock"].get())
        poids = float(self.entries["poids"].get())
        pays_origine = self.entries["pays_origine"].get()

        # Créer un objet Marchandise à partir des données saisies
        merchandise = Marchandise(nom_produit, prix, quantite_stock, poids, pays_origine)

        # Ajouter la marchandise à la liste
        self.merchandise_list.append(merchandise)
        self.merchandise_textbox.insert(tk.END, f"{merchandise.nom_produit} a été ajouté à la liste des marchandises.\n")

        # Vider les champs de saisie
        for entry in self.entries.values():
            entry.delete(0, tk.END)

    def show_merchandise(self):
        # Afficher toutes les marchandises dans la zone de texte
        if len(self.merchandise_list) == 0:
            self.merchandise_textbox.insert(tk.END, "Il n'y a pas de marchandises.")
        else:
            self.merchandise_textbox.delete("1.0", tk.END)
            for merchandise in self.merchandise_list:
                self.merchandise_textbox.insert(tk.END, f"Nom du produit : {merchandise.nom_produit}\n")
                self.merchandise_textbox.insert(tk.END, f"Prix : {merchandise.prix}\n")
                self.merchandise_textbox.insert(tk.END, f"Quantité en stock : {merchandise.quantite_stock}\n")
                self.merchandise_textbox.insert(tk.END, f"Poids : {merchandise.poids}\n")
                self.merchandise_textbox.insert(tk.END, f"Pays d'origine : {merchandise.pays_origine}\n\n")

class Marchandise:
    def __init__(self, nom_produit, prix, quantite_stock, poids, pays_origine):
        self.nom_produit = nom_produit
        self.prix = prix
        self.quantite_stock = quantite_stock
        self.poids = poids
        self.pays_origine = pays_origine
