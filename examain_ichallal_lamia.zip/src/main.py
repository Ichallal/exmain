import tkinter as tk
from client import Clients
from marchandise import Marchandises
from employes import ListeEmployes 
class GUI:
    def __init__(self, master):
        self.master = master
        master.title("GUI Example")

        self.class1_button = tk.Button(master, text="Class 1", command=self.create_class1_window)
        self.class1_button.pack()

        self.class2_button = tk.Button(master, text="Class 2", command=self.create_class2_window)
        self.class2_button.pack()

        self.class3_button = tk.Button(master, text="Class 3", command=self.create_class3_window)
        self.class3_button.pack()

    # jai instancier la class client avec 5 clienst differents mais je compte les ajouter avec linterface graphique a fur et a mesure que la personne rajoute des clients
    # c'est juste pour la specifications demandée dans le document de l'examains  
    """ self.client_1 = Clients("mruyfeg", "hdhfgeru"," 59 evenue boudoin le bourget " ,1234567890);
        self.client_2 = Clients("mruyfeg", "hdhfgeru"," 59 evenue boudoin le bourget " ,1234567890);
        self.client_3 = Clients("mruyfeg", "hdhfgeru"," 59 evenue boudoin le bourget " ,1234567890);
        self.client_4 = Clients("mruyfeg", "hdhfgeru"," 59 evenue boudoin le bourget " ,1258798989);
    # appel a la methode pour mettre les objet cree dans une liste 
        self.liste_clients()
    """
        
    def liste_clients(self): 
        self.liste_etudiants = [self.client_1, self.client_2, self.client_3, self.client_4]

    def create_class1_window(self):
        class1_window = tk.Toplevel(self.master)
        class1 = Clients(class1_window)

    def create_class2_window(self):
        class2_window = tk.Toplevel(self.master)
        class2 = Marchandises(class2_window)
    
    def create_class3_window(self):
        class3_window = tk.Toplevel(self.master)
        class3 = ListeEmployes(class3_window)


# Créer la fenêtre principale
root = tk.Tk()

# Créer l'interface graphique
gui = GUI(root)

# Lancer la boucle principale
root.mainloop()