import tkinter as tk
class ListeEmployes:
    app_employes = " App" 

    def __init__(self, master):
        self.master = master
        self.master.title("Liste des employés")
        self.label = tk.Label(self.master, text="Liste des employés")
        self.label.pack()
        self.employe_list = []

        # Créer une zone de texte pour afficher les employés
        self.employe_textbox = tk.Text(self.master, height=10, width=50)
        self.employe_textbox.pack()

        # Créer les champs pour les données des employés
        fields = [("Nom :", "nom"), ("Prénom :", "prenom"), ("Poste :", "poste"), ("Salaire :", "salaire"), ("salaire par année (séparés par une virgule) :", "annees_experience_salaire")]
        self.entries = {}
        for label_text, attr_name in fields:
            label = tk.Label(self.master, text=label_text)
            label.pack()
            entry = tk.Entry(self.master)
            self.entries[attr_name] = entry
            entry.pack()

        # Bouton pour ajouter un employé
        self.add_employe_button = tk.Button(self.master, text="Ajouter un employé", command=self.add_employe)
        self.add_employe_button.pack()

        # Bouton pour afficher les employés
        self.show_employe_button = tk.Button(self.master, text="Afficher les employés", command=self.show_employe)
        self.show_employe_button.pack()

    def add_employe(self):
        # Récupérer les données de l'employé à ajouter
        nom = self.entries["nom"].get()
        prenom = self.entries["prenom"].get()
        poste = self.entries["poste"].get()
        salaire = float(self.entries["salaire"].get())
        annees_experience_salaire = self.entries["annees_experience_salaire"].get().split(',')

        # Créer un objet Employe à partir des données saisies
        employe = Employe(nom, prenom, poste, salaire, annees_experience_salaire)

        # Ajouter l'employé à la liste
        self.employe_list.append(employe)
        self.employe_textbox.insert(tk.END, f"{employe.prenom} {employe.nom} a été ajouté à la liste des employés.\n")

        # Vider les champs de saisie
        for entry in self.entries.values():
            entry.delete(0, tk.END)

    def show_employe(self):
        # Afficher tous les employés dans la zone de texte
        if len(self.employe_list) == 0:
            self.employe_textbox.insert(tk.END, "Il n'y a pas d'employés.")
        else:
            self.employe_textbox.delete("1.0", tk.END)
            for employe in self.employe_list:
                self.employe_textbox.insert(tk.END, f"{employe.nom} {employe.prenom} - {employe.poste} - Salaire: {employe.salaire} - Années d'expérience et salaire: {', '.join(employe.annees_experience_salaire)}\n")

    def calculer_salaire_moyen(self):
                total_salaire = self.salaire
                total_annees_experience = 0
                for annee_exp_salaire in self.annees_experience_salaire:
                    annee, salaire = annee_exp_salaire.split()
                    total_annees_experience += int(annee)
                    total_salaire += float(salaire)
                return total_salaire / (len(self.annees_experience_salaire) + 1)

class Employe:
    def __init__(self, nom, prenom, poste, salaire, annees_experience_salaire):
        self.nom = nom
        self.prenom = prenom
        self.poste = poste
        self.salaire = salaire
        self.annees_experience_salaire = annees_experience_salaire

    