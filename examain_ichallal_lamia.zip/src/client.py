import tkinter as tk
from datetime import datetime
class Clients:
    nb_clients = 0
    def __init__(self, master):
        self.master = master
        self.master.title("Clients")
        self.label = tk.Label(self.master, text="Clients")
        self.label.pack()
        self.clients = []

        # Créer une zone de texte pour afficher les clients
        self.clients_textbox = tk.Text(self.master, height=10, width=50)
        self.clients_textbox.pack()

        # Champ pour le nom du client
        self.nom_label = tk.Label(self.master, text="Nom :")
        self.nom_label.pack()
        self.nom_entry = tk.Entry(self.master)
        self.nom_entry.pack()

        # Champ pour le prénom du client
        self.prenom_label = tk.Label(self.master, text="Prénom :")
        self.prenom_label.pack()
        self.prenom_entry = tk.Entry(self.master)
        self.prenom_entry.pack()

        # Champ pour l'adresse du client
        self.adresse_label = tk.Label(self.master, text="Adresse :")
        self.adresse_label.pack()
        self.adresse_entry = tk.Entry(self.master)
        self.adresse_entry.pack()

        # Champ pour le numéro de téléphone du client
        self.num_tel_label = tk.Label(self.master, text="Numéro de téléphone :")
        self.num_tel_label.pack()
        self.num_tel_entry = tk.Entry(self.master)
        self.num_tel_entry.pack()

         # Champ pour le numéro de téléphone du client
        self.Date_label = tk.Label(self.master, text="Date de naissance :")
        self.Date_label.pack()
        self.Date_entry = tk.Entry(self.master)
        self.Date_entry.pack()

        # Bouton pour ajouter un client
        self.add_client_button = tk.Button(self.master, text="Ajouter un client", command=self.ajouter_client)
        self.add_client_button.pack()

        # Bouton pour afficher les clients
        self.show_clients_button = tk.Button(self.master, text="Afficher les clients", command=self.show_clients)
        self.show_clients_button.pack()


        self.age_moyen_button = tk.Button(self.master, text="Age moyen des clients", command=self.age_moyen_clients)
        self.age_moyen_button.pack()

    def ajouter_client(self):
        # Récupérer le nom, le prénom, l'adresse, le numéro de téléphone et la date de naissance du client à ajouter
        nom = self.nom_entry.get()
        prenom = self.prenom_entry.get()
        adresse = self.adresse_entry.get()
        num_tel = self.num_tel_entry.get()
        date_naissance = self.Date_entry.get()

        # Créer un objet Client à partir des données saisies
        client = Client(nom=nom, prenom=prenom, adresse=adresse, num_tel=num_tel, date_naissance=date_naissance)

        # Ajouter le client à la liste
        self.clients.append(client)
        self.clients_textbox.insert(tk.END, f"{client.prenom} {client.nom} a été ajouté à la liste des clients.\n")

        # Vider les champs de saisie
        self.nom_entry.delete(0, tk.END)
        self.prenom_entry.delete(0, tk.END)
        self.adresse_entry.delete(0, tk.END)
        self.num_tel_entry.delete(0, tk.END)
        self.Date_entry.delete(0, tk.END)

    # Afficher la liste des clients mise à jour

        # Afficher la liste des clients mise à jour


    def show_clients(self):
        # Vider la zone de texte
        self.clients_textbox.delete('1.0', tk.END)

        # Afficher la liste des clients dans la zone de texte
        self.clients_textbox.insert(tk.END, "Liste des clients :\n")
        for client in self.clients:
            self.clients_textbox.insert(tk.END, f"{client}\n")
    def age_moyen_clients(self):
        if len(self.clients) == 0:
            return
        total_age = 0
        age_list = []

        for client in self.clients:
            age = client.age()
            total_age += age
            age_list.append(age)
        
        average_age = total_age / len(self.clients)

        # Afficher les âges séparément
        self.clients_textbox.insert(tk.END, "Âges des clients :\n")
        for age in age_list:
            self.clients_textbox.insert(tk.END, f"{age}\n")

        # Afficher l'âge moyen des clients
        self.clients_textbox.insert(tk.END, f"Âge moyen des clients : {average_age}\n")

    
class Client:
    def __init__(self, nom, prenom, adresse, num_tel,date_naissance):
        self.nom = nom
        self.prenom = prenom
        self.adresse = adresse
        self.num_tel = num_tel
        self.date_naissance = datetime.strptime(date_naissance, "%d/%m/%Y")

    def __str__(self):
        return f"{self.prenom} {self.nom} ({self.adresse}, {self.num_tel})"

    def age(self):
        today = datetime.today()
        age = today.year - self.date_naissance.year
        if (today.month, today.day) < (self.date_naissance.month, self.date_naissance.day):
            age -= 1
        return age